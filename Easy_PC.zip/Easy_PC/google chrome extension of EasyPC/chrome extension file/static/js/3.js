webpackJsonp([3],{

/***/ "8Dc2":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "niH5":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./src/css/materialize/_switches.scss
var _switches = __webpack_require__("oUTl");
var _switches_default = /*#__PURE__*/__webpack_require__.n(_switches);

// EXTERNAL MODULE: ./src/js/constants.js
var constants = __webpack_require__("jOjl");

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/Settings.vue
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ var Settings = ({
  name: 'settings',
  props: {
    popup: Boolean
  },
  mounted: function mounted() {},

  computed: {
    isNewTabEnabled: function isNewTabEnabled() {
      return this.$store.getters.isNewTabEnabled;
    },
    isOtpPushAlertEnabled: function isOtpPushAlertEnabled() {
      return this.$store.getters.isOtpPushAlert;
    },
    isDarkTheme: function isDarkTheme() {
      return this.$store.getters.isDarkTheme;
    }
  },
  methods: {
    toggleTheme: function toggleTheme(event) {
      console.count('toggleTheme');
      window.trackEvent('settings', 'toggle-theme');
      this.$store.dispatch('setDarkTheme');
    },
    toggleNewTab: function toggleNewTab(event) {
      window.trackEvent('settings', 'toggle-new-tab');
      this.$store.dispatch('toggleNewTab');
    },
    toggleOtpPushAlert: function toggleOtpPushAlert(event) {
      window.trackEvent('settings', 'toggle-otp-push-alert');
      this.$store.dispatch('toggleOtpPushAlert');
    },
    logout: function logout() {
      window.trackEvent('settings', 'logout');
      var data = {};
      data[constants["a" /* default */].key_reset] = true;
      window.chrome.runtime.sendMessage(data);
    }
  }
});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-57363dbf","hasScoped":true,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/Settings.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"overlay",class:{'overlay-popup': _vm.popup},attrs:{"id":"bottom-sheet"}},[_c('div',{staticClass:"social",class:{'overlay-popup': _vm.popup},attrs:{"tabindex":"-1","role":"dialog","aria-labelledby":"modal-label","aria-hidden":"true"}},[_c('div',{staticClass:"settings-button"},[_vm._m(0),_vm._v(" "),_c('div',{staticClass:"switch"},[_c('label',[_c('input',{attrs:{"type":"checkbox"},domProps:{"checked":_vm.isDarkTheme ? 'checked' : ''},on:{"click":_vm.toggleTheme}}),_vm._v(" "),_c('span',{staticClass:"lever"})])])]),_vm._v(" "),_c('div',{staticClass:"settings-button",on:{"click":_vm.toggleNewTab}},[_vm._m(1),_vm._v(" "),_c('div',{staticClass:"switch"},[_c('label',[_c('input',{attrs:{"type":"checkbox"},domProps:{"checked":_vm.isNewTabEnabled ? 'checked' : ''},on:{"click":_vm.toggleNewTab}}),_vm._v(" "),_c('span',{staticClass:"lever"})])])]),_vm._v(" "),_c('div',{staticClass:"settings-button",on:{"click":_vm.toggleOtpPushAlert}},[_vm._m(2),_vm._v(" "),_c('div',{staticClass:"switch"},[_c('label',[_c('input',{attrs:{"type":"checkbox"},domProps:{"checked":_vm.isOtpPushAlertEnabled ? 'checked' : ''},on:{"click":_vm.toggleOtpPushAlert}}),_vm._v(" "),_c('span',{staticClass:"lever"})])])]),_vm._v(" "),_c('div',{staticClass:"settings-button",on:{"click":_vm.logout}},[_c('p',[_vm._v("Logout")])])]),_vm._v(" "),_c('a',{staticClass:"btn-close",attrs:{"href":"#close","aria-hidden":"true"}})])}
var staticRenderFns = [function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticStyle:{"flex":"1"}},[_c('p',[_vm._v("Dark Theme")])])},function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticStyle:{"flex":"1"}},[_c('p',[_vm._v("Crono on New Tab")])])},function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticStyle:{"flex":"1"}},[_c('p',[_vm._v("One Time Password (OTP) push alert")])])}]
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ var components_Settings = (esExports);
// CONCATENATED MODULE: ./src/components/Settings.vue
function injectStyle (ssrContext) {
  __webpack_require__("8Dc2")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-57363dbf"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  Settings,
  components_Settings,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var src_components_Settings = __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "oUTl":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ })

});
//# sourceMappingURL=3.js.map