/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "DtrW");
/******/ })
/************************************************************************/
/******/ ({

/***/ "DtrW":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__constants__ = __webpack_require__("jOjl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__config__ = __webpack_require__("Pqsl");



var store = window.store;
store.dispatch('updateActions', {});

window.onNotificationActionAdded = function (key, action) {
  var actions = store.getters.getActions;

  if (actions.hasOwnProperty(key)) {
    var oldAction = actions[key];
    var shouldUpdate = false;
    if (oldAction.hasOwnProperty('text')) {
      if (!action.hasOwnProperty('text')) {
        shouldUpdate = true;
      } else {
        shouldUpdate = shouldUpdate || action.text !== oldAction.text;
      }
    }

    shouldUpdate = shouldUpdate || action.label !== oldAction.label || action.triggered !== oldAction.triggered || action.type !== oldAction.type;

    if (shouldUpdate) {
      actions[key] = action;
      store.dispatch('updateActions', actions);
    }
  } else {
    actions[key] = action;
    store.dispatch('updateActions', actions);
  }
};

window.onNotificationActionRemoved = function (key, action) {
  var actions = store.getters.getActions;
  delete actions[key];
  store.dispatch('updateActions', actions);
};

window.onNotificationActionChanged = function (key, action) {
  window.onNotificationActionAdded(key, action);
};

window.chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.hasOwnProperty(__WEBPACK_IMPORTED_MODULE_0__constants__["a" /* default */].key_notification_action)) {
    var notificationId = request[__WEBPACK_IMPORTED_MODULE_0__constants__["a" /* default */].notification_action_notification_id];
    var actionLabel = request[__WEBPACK_IMPORTED_MODULE_0__constants__["a" /* default */].notification_action_label];
    var actionId = request[__WEBPACK_IMPORTED_MODULE_0__constants__["a" /* default */].notification_action_id];
    var deviceId = store.getters.getDeviceId;
    var deviceToken = store.getters.getDeviceToken;

    var actions = store.getters.getActions;
    if (actions.hasOwnProperty(notificationId) && actions[notificationId].hasOwnProperty(actionId)) {
      actions[notificationId][actionId]['triggered'] = 1;
      store.dispatch('updateActions', actions);
    }

    var xhttp = new XMLHttpRequest();
    xhttp.open('POST', __WEBPACK_IMPORTED_MODULE_1__config__["a" /* default */].apiUrl + 'sendActionToDeviceV2', true);
    xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhttp.setRequestHeader('accept', 'application/json');

    var body = 'deviceToken=' + deviceToken + '&notificationId=' + notificationId + '&actionLabel=' + actionLabel + '&deviceId=' + deviceId + '&actionId=' + actionId;
    xhttp.send(body);
    window.trackEvent('notification', 'action-button');
  } else if (request.hasOwnProperty(__WEBPACK_IMPORTED_MODULE_0__constants__["a" /* default */].key_notification_action_text)) {
    var _notificationId = request[__WEBPACK_IMPORTED_MODULE_0__constants__["a" /* default */].notification_action_notification_id];
    var _actionLabel = request[__WEBPACK_IMPORTED_MODULE_0__constants__["a" /* default */].notification_action_label];
    var _actionId = request[__WEBPACK_IMPORTED_MODULE_0__constants__["a" /* default */].notification_action_id];
    var text = request[__WEBPACK_IMPORTED_MODULE_0__constants__["a" /* default */].notification_action_text];
    var _deviceId = store.getters.getDeviceId;
    var _deviceToken = store.getters.getDeviceToken;
    var _actions = store.getters.getActions;

    if (_actions.hasOwnProperty(_notificationId) && _actions[_notificationId].hasOwnProperty(_actionId)) {
      _actions[_notificationId][_actionId]['triggered'] = 1;
      _actions[_notificationId][_actionId]['text'] = text;
      store.dispatch('updateActions', _actions);
    }

    var _xhttp = new XMLHttpRequest();
    _xhttp.open('POST', __WEBPACK_IMPORTED_MODULE_1__config__["a" /* default */].apiUrl + 'sendTextActionToDeviceV2', true);
    _xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    _xhttp.setRequestHeader('accept', 'application/json');

    var _body = 'deviceToken=' + _deviceToken + '&notificationId=' + _notificationId + '&actionLabel=' + _actionLabel + '&deviceId=' + _deviceId + '&actionId=' + _actionId + '&text=' + text;
    _xhttp.send(_body);
    window.trackEvent('notification', 'action-text');
  }
});

/***/ }),

/***/ "Pqsl":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = ({
  // firebaseConfig: {
  //   apiKey: 'AIzaSyD039mcK7ScS2-ek87FZyrA2R4pONTVX0Q',
  //   authDomain: 'crono-stag.firebaseapp.com',
  //   databaseURL: 'https://crono-stag.firebaseio.com',
  //   projectId: 'crono-stag',
  //   storageBucket: 'crono-stag.appspot.com',
  //   messagingSenderId: '825687005344'
  // },
  // apiUrl: 'https://us-central1-crono-stag.cloudfunctions.net/'

  // Production config
  firebaseConfig: {
    apiKey: 'AIzaSyBUFWwk27G6yKVzrJAqbFMG1BhBytQNFeA',
    authDomain: 'crono-production.firebaseapp.com',
    databaseURL: 'https://crono-production.firebaseio.com',
    projectId: 'crono-production',
    storageBucket: 'crono-production.appspot.com',
    messagingSenderId: '970803141031'
  },
  apiUrl: 'https://us-central1-crono-production.cloudfunctions.net/'
});

/***/ }),

/***/ "jOjl":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = ({
  uploadFileOffline: 'upload_file_offline',
  sendPushNotification: 'send_push_notification',
  key_clipboard: 'key_clipboard',
  key_new_tab: 'key_new_tab',
  new_tab_url: 'new_tab_url',
  windowId: 'windowId',
  key_refresh_masonry: 'key_refresh_masonry',
  key_update_masonry: 'key_update_masonry',
  key_delete_notification: 'key_delete_notification',
  notification_id: 'notification_id',
  key_notification_action: 'key_notification_action',
  key_notification_action_text: 'key_notification_action_text',
  notification_action_label: 'notification_action_label',
  notification_action_id: 'notification_action_id',
  notification_action_text: 'notification_action_text',
  notification_action_notification_id: 'notification_action_notification_id',
  key_reset: 'key_reset',
  key_file_upload_on_click: 'key_file_upload_on_click',
  push_alerts: {
    key_enable_all: 'key_enable_all',
    key_disable_all: 'key_disable_all',
    key_toggle_selected: 'key_toggle_selected',
    package_name: 'package_name'
  },
  reply_window: {
    key_reply_window: 'key_reply_window',
    notification_id: 'notifications_id'
  },
  ga: {
    notification: 'notification',
    push_alerts: 'push-alerts',
    browser_action: 'browser-action'
  },
  key_ring_device: 'key_ring_device'
});

/***/ })

/******/ });
//# sourceMappingURL=notificationActions.js.map