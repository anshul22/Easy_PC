(function(modules) { 

var installedModules = {};

function __webpack_require__(moduleId) {

/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "0say");
/******/ })
/************************************************************************/
/******/ ({

/***/ "0say":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__constants__ = __webpack_require__("jOjl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__config__ = __webpack_require__("Pqsl");



var store = window.store;

window.handleDeviceClipboard = function (clipboardData) {
  store.dispatch('updateClipboard', clipboardData);
};

var getClipboardContent = function getClipboardContent() {
  var bg = void 0;
  if (window.isChrome()) {
    bg = window.chrome.extension.getBackgroundPage(); // get the background page
  } else {
    bg = window.browser.extension.getBackgroundPage(); // get the background page
  }
  bg.document.body.innerHTML = ''; // clear the background page

  // add a DIV, contentEditable=true, to accept the paste action
  var helperdiv = bg.document.createElement('div');
  document.body.appendChild(helperdiv);
  helperdiv.contentEditable = true;

  // focus the helper div's content
  var range = document.createRange();
  range.selectNode(helperdiv);
  window.getSelection().removeAllRanges();
  window.getSelection().addRange(range);
  helperdiv.focus();

  // trigger the paste action
  bg.document.execCommand('Paste');

  // read the clipboard contents from the helperdiv
  var clipBoardWithFormatting = helperdiv.innerHTML;
  var doc = new DOMParser().parseFromString(clipBoardWithFormatting, 'text/html');
  return doc.body.textContent;
};

window.chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.hasOwnProperty(__WEBPACK_IMPORTED_MODULE_0__constants__["a" /* default */].key_clipboard)) {
    var clipboardData = getClipboardContent();
    var token = store.getters.getDeviceToken;

    var url = __WEBPACK_IMPORTED_MODULE_1__config__["a" /* default */].apiUrl + 'sendClipboardToDevice' + '?token=' + token + '&clipboard=' + encodeURI(clipboardData);

    var xhttp = new XMLHttpRequest();
    xhttp.open('GET', url, true);
    xhttp.send(null);
    window.trackEvent('clipboard', 'send-to-device');

    var payload = {
      title: 'Clipboard shared with device',
      message: clipboardData,
      type: 'basic'
    };
    window.showFileStatusNotification('c-' + new Date().getTime(), payload);
  }
});

/***/ }),

/***/ "Pqsl":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = ({
  // firebaseConfig: {
  //   apiKey: 'AIzaSyD039mcK7ScS2-ek87FZyrA2R4pONTVX0Q',
  //   authDomain: 'crono-stag.firebaseapp.com',
  //   databaseURL: 'https://crono-stag.firebaseio.com',
  //   projectId: 'crono-stag',
  //   storageBucket: 'crono-stag.appspot.com',
  //   messagingSenderId: '825687005344'
  // },
  // apiUrl: 'https://us-central1-crono-stag.cloudfunctions.net/'

  // Production config
  firebaseConfig: {
    apiKey: 'AIzaSyBUFWwk27G6yKVzrJAqbFMG1BhBytQNFeA',
    authDomain: 'crono-production.firebaseapp.com',
    databaseURL: 'https://crono-production.firebaseio.com',
    projectId: 'crono-production',
    storageBucket: 'crono-production.appspot.com',
    messagingSenderId: '970803141031'
  },
  apiUrl: 'https://us-central1-crono-production.cloudfunctions.net/'
});

/***/ }),

/***/ "jOjl":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = ({
  uploadFileOffline: 'upload_file_offline',
  sendPushNotification: 'send_push_notification',
  key_clipboard: 'key_clipboard',
  key_new_tab: 'key_new_tab',
  new_tab_url: 'new_tab_url',
  windowId: 'windowId',
  key_refresh_masonry: 'key_refresh_masonry',
  key_update_masonry: 'key_update_masonry',
  key_delete_notification: 'key_delete_notification',
  notification_id: 'notification_id',
  key_notification_action: 'key_notification_action',
  key_notification_action_text: 'key_notification_action_text',
  notification_action_label: 'notification_action_label',
  notification_action_id: 'notification_action_id',
  notification_action_text: 'notification_action_text',
  notification_action_notification_id: 'notification_action_notification_id',
  key_reset: 'key_reset',
  key_file_upload_on_click: 'key_file_upload_on_click',
  push_alerts: {
    key_enable_all: 'key_enable_all',
    key_disable_all: 'key_disable_all',
    key_toggle_selected: 'key_toggle_selected',
    package_name: 'package_name'
  },
  reply_window: {
    key_reply_window: 'key_reply_window',
    notification_id: 'notifications_id'
  },
  ga: {
    notification: 'notification',
    push_alerts: 'push-alerts',
    browser_action: 'browser-action'
  },
  key_ring_device: 'key_ring_device'
});

})

 });
